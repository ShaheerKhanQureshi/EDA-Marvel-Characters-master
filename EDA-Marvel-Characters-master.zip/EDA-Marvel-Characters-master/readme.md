An Exploratory Data analysis on Marvel characters

Kaggle Dataset Link: https://www.kaggle.com/datasets/syedasimalishah/marvel-chracters
